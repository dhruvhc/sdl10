from django.contrib import admin
from .models import Seller, Chat

admin.site.register(Seller)
admin.site.register(Chat)
