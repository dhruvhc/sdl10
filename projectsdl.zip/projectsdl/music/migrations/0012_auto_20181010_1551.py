# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('music', '0011_auto_20181010_1451'),
    ]

    operations = [
        migrations.RenameField(
            model_name='seller',
            old_name='grp_photo',
            new_name='BookSet_Photo',
        ),
        migrations.RenameField(
            model_name='seller',
            old_name='description',
            new_name='Description',
        ),
        migrations.RenameField(
            model_name='seller',
            old_name='key',
            new_name='Key',
        ),
        migrations.RenameField(
            model_name='seller',
            old_name='subjects',
            new_name='Subjects',
        ),
        migrations.RenameField(
            model_name='seller',
            old_name='total_price',
            new_name='Total_Price',
        ),
        migrations.RemoveField(
            model_name='seller',
            name='status',
        ),
    ]
